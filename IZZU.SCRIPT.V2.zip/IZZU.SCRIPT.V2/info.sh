#!/bin/bash
clear
neofetch --ascii_distro SliTaz
echo ' Created by IZZUVPN '
echo ''
cat /root/log-install.txt
echo ""
