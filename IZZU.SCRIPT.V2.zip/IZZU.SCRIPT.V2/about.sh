#!/bin/bash

clear
echo -e "=================================================" | lolcat
echo -e "         Premium Auto Script By IZZUVPN         " | lolcat
echo -e "-----------------------------------------------" | lolcat
echo -e ""
figlet IZZUVPN | lolcat
figlet AutoScript | lolcat
echo '         	        UNLIMITED BOSKU!              " | lolcat
echo ''
echo '         ......................................     " | lolcat
echo '                      Build in 2022                 " | lolcat
echo '                  TELEGRAM : @izZUvpn               " | lolcat
echo -e "=================================================" | lolcat
